from supabase.lib import auth_client, realtime_client

__all__ = ["auth_client", "realtime_client"]
